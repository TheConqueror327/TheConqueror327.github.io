import math
l = list(map(lambda x: list(map(int, x.split('.'))), open('input.txt').read().split('\n')))

def getMinOrMax(li: list, minOrMax: str, n: int):
    out = []
    if minOrMax == 'min':
        while len(out) != n:
            out.append(min(li))
            li.remove(min(li))
    else:
        while len(out) != n:
            out.append(max(li))
            li.remove(max(li))
    return out

def second(li: list):
    out = []
    for i in li:
        if i % 2 == 0:
            out.append(i)
    return max(out)

def third(li: list):
    out = []
    for i in li:
        if i > 14:
            out.append(i)
    return min(out)

def fourth(li: list):
    return round(sum(li) / len(li), 2)

def fifth(li: list):
    out = []
    for i in li:
        if i < 14:
            out.append(i ** 2)
    return sum(out)

def sixth(li: list):
    out = 1
    for i in li:
        out *= i
    return round(math.log10(out))

def seventh(li: list):
    out = []
    for i in li:
        for o in i:
            out.append(o)
    return sum(getMinOrMax(out, 'min', 12))
        

forms = [
    '. sorban szereplő páros számok maximuma: ',
    '. sorban szereplő 14-nél nagyobb számok minimuma: ',
    '. sorban szereplő 15 legkisebb szám számtani közepe: ',
    '. sorban szereplő 14-nél kisebb számok négyzeteinek összege: ',
    '. sorban szereplő 10 legnagyobb szám szorzatának nagyságrendje: 10^',
    'Az inputban szereplő összes szám közül a 12 legkisebb szám összege: '
]

az = [1, 5]
solutions = [
    second(l[0]),
    third(l[1]),
    fourth(getMinOrMax(l[2], 'min', 15)),
    fifth(l[3]),
    sixth(getMinOrMax(l[4], 'max', 10)),
    seventh(l)
]

def main():
    for i in range(5):
        if i + 1 in az:
            print(f'Az {i + 1}{forms[i]}{solutions[i]}')
        else:
            print(f'A {i + 1}{forms[i]}{solutions[i]}')
    print(f'{forms[i + 1]}{solutions[i + 1]}')

main()